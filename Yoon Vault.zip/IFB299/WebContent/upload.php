<?php
if(!empty($_FILES)){
    
    //database configuration
    $dbHost = 'localhost';
    $dbUsername = 'root';
    $dbPassword = 'root';
    $dbName = 'Media_Vault_Schema'; 
    
    //connect with the database
    $conn = new mysqli($dbHost, $dbUsername, $dbPassword, $dbName);
    if($mysqli->connect_errno){
        echo "Failed to connect to MySQL: (" . $mysqli->connect_errno . ") " . $mysqli->connect_error;
    }
 
 	$userName = $dbUsername;
    $targetDir = "uploads/";
    $fileName = $_FILES['file']['name'];
    $targetFile = $targetDir.$fileName;
    $fileType = filetype($fileName);
    $fileSize = filesize($fileName);
    
    //$fileLocation = 
    
    $fileId = uniqid($userName);
    
    //metaData place holder
    //$metaData = 
    
 	   
    if(move_uploaded_file($_FILES['file']['tmp_name'],$targetFile)){
        //insert file information into db table
        $conn->query("INSERT INTO file_details (
        user_name,
        file_id,
        file_type,
        file_name, 
        file_size,
        //file_location,
        //metaData
        creation_date
        ) 
        
        VALUES(
        '".$userName."',
        '".$fileId."',
        '".$fileType."',
        '".$fileName."',
        '".$fileSize."',
        //'".$fileLocation."',
        //metaData
        '".date("Y-m-d H:i:s")."')"
        );
    }
    
}
?>